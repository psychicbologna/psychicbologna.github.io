<?php
/* vim: set expandtab sw=4 ts=4 sts=4: */
/**
 * The MERGE storage engine
 *
 * @package PhpMyAdmin-Engines
 */
namespace PhpMyAdmin\Engines;

use PhpMyAdmin\StorageEngine;

/**
 * The MERGE storage engine
 *
 * @package PhpMyAdmin-Engines
 */
class Merge extends StorageEngine
{
}

